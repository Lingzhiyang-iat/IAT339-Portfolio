package main;


/**
 GameMain — Entry point for "Cyber City Farm":
 */

import javax.swing.JFrame;

public class GameMain {
    public static void main(String[] args) {
        // Create a window
        JFrame frame = new JFrame("Cyber City Farm");
        
        // Create an instance of FarmPanel
        FarmPanel panel = new FarmPanel();
        frame.setContentPane(panel);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                panel.stopMusic();
            }
        });
        
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        frame.pack();  // Auto resize to panel's preferred size
        frame.setLocationRelativeTo(null);  // Center on screen
        frame.setVisible(true);  // Show the window
    }
}