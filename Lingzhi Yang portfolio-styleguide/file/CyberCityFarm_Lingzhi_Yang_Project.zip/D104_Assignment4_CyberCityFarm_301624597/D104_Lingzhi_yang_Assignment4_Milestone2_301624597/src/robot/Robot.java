package robot;

import creature.Creature;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * [EN] Robot — Enemy creature:
 *  - Extends Creature, has normal and eating sprites.
 *  - Spawns at random side and vertical position below the rabbit.
 *  - Moves with random horizontal and vertical velocity, bounces within panel bounds.
 *  - Can enter eating animation with bobbing effect for a set duration.
 */


public class Robot extends Creature {
    private BufferedImage normalImg;   //normal sprite
    private BufferedImage eatingImg;   //eating sprite
    private boolean isEating = false;
    private long eatStart = 0L;
    private int eatDuration = 700;     

    private final Random rng = new Random();
    private int bobAmp = 5;
    public boolean hitLock = false;    // avoid repeated hits while overlapping

    public Robot(BufferedImage normalImg, BufferedImage eatingImg,
                 int panelW, int panelH, int rabbitY) {
        this.normalImg = normalImg;
        this.eatingImg = eatingImg;

        // uniform size
        this.w = 100;
        this.h = 90;

        // spawn below the rabbit
        int minY = rabbitY + 20;
        int maxY = Math.max(minY, panelH - h - 10);
        this.y = minY + (maxY > minY ? rng.nextInt(maxY - minY + 1) : 0);

        // random velocities
        int baseH = 2 + rng.nextInt(3); // 2~4
        int baseV = 1 + rng.nextInt(3); // 1~3

        //  spawn from left or right
        boolean fromLeft = rng.nextBoolean();
        if (fromLeft) {
            this.x = -w - 5;
            this.vx = +baseH;
        } else {
            this.x = panelW + 5;
            this.vx = -baseH;
        }

        // random vertical direction
        this.vy = rng.nextBoolean() ? +baseV : -baseV;
    }


    public void update(int panelW, int panelH, int rabbitY) {
        // base movement
        super.update(panelW, panelH);

        //bounce
        if (x <= 0) {
            x = 0;
            vx = Math.abs(vx);
        } else if (x + w >= panelW) {
            x = panelW - w;
            vx = -Math.abs(vx);
        }

     
        int minY = rabbitY + 20;
        if (y <= minY) {
            y = minY;
            vy = Math.abs(vy);
        }

        if (y + h >= panelH) {
            y = panelH - h;
            vy = -Math.abs(vy);
        }
    }

    //start eating animation
    public void startEating() {
        isEating = true;
        eatStart = System.currentTimeMillis();
    }

  //start eating with custom duration
    public void startEating(int durationMs) {
        this.eatDuration = durationMs;
        startEating();
    }

    @Override
    public void draw(Graphics2D g2) {
        //  stop eating after duration
        if (isEating && System.currentTimeMillis() - eatStart > eatDuration) {
            isEating = false;
        }

        // select sprite
        BufferedImage img = (isEating && eatingImg != null) ? eatingImg : normalImg;

        // bob while eating
        int dy = 0;
        if (isEating) {
            long t = System.currentTimeMillis() - eatStart;
            dy = (int) Math.round(Math.sin(t / 60.0) * bobAmp);
        }

        
        drawImage(g2, img, dy, 0);
    }


    @Override
    public Rectangle getBounds() {
        return super.getBounds();
    }
}
