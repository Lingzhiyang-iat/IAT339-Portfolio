package main;


import ddf.minim.Minim;
import ddf.minim.AudioSample;
import ddf.minim.AudioPlayer;
import util.MinimHelper;
import util.ImageLoader;
import rabbit.Rabbit;
import robot.Robot;              
import rabbit.Bullet;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.util.ArrayList;

/**
 * FarmPanel — Main game panel for "Cyber City Farm":
 *  - Manages game states: intro, playing, game over.
 *  - Handles rabbit feeding, carrot planting/harvest, and bad carrot ammo.
 *  - Spawns robots in timed intervals, updates movement, collisions, and damage logic.
 *  - Draws background, crops, clouds, rabbit, robots, bullets, UI buttons, and tips.
 *  - Plays background music and sound effects (shooting, eating) via Minim.
 *  - Includes celebration effects, survival time tracking, and start/game-over screens.
 
 * This multimedia game simulates a farming environment where the player plants seeds,
 * harvests crops, and protects a rabbit from attacking robots.  
 * Key features include:
 * - Intro screen with instructions and start button
 * - Planting, harvesting, and feeding interactions
 * - Animated rabbit with health bar and feeding animation
 * - Robots that move and attack, with collision detection
 * - Shooting bullets to defend against robots
 * - Timed messages and survival time tracking
 * - Sound effects and background elements
 */
public class FarmPanel extends JPanel implements MouseListener, MouseMotionListener {

	private long tipStartMs = 0L;
	private static final long TIP_DURATION_MS = 3000;
	
	private long robotTipStartMs = 0L;
	private static final long ROBOT_TIP_DURATION_MS = 3000;

	
	// SurviveSeconds
	private long runStartMs = 0L;
	private long surviveSeconds = 0L;
	
	
	
    //Background & assets
    private BufferedImage bgImg;
    private BufferedImage seedImg;
    private BufferedImage carrotImg, badCarrotImg;

    //Field tiles
    private int tileRows = 2;
    private int tileCols = 6;
    private int tileWidth = 96;
    private int tileHeight = 96;
    private int fieldStartX = 110;
    private int fieldStartY = 500;

    // Seed icon position (toolbar)
    private int seedIconX = 790;
    private int seedIconY = 520;
    private int seedIconW = 64, seedIconH = 64;

    // Interaction states
    private boolean holdingSeed = false;  // holding a seed or not
    private int mouseX = 0, mouseY = 0;   // mouse position

    //  Per-tile crop state
    private boolean[][] tileHasSeed = new boolean[tileRows][tileCols]; // 正在生长中的“种子”标记 / seed growing flag
    private int[][] cropState = new int[tileRows][tileCols];           // 成熟状态 / mature state
    private Timer[][] growTimers = new Timer[tileRows][tileCols];      // 生长计时器 / growth timers

    // crop states
    private static final int SEED_STATE = 0;
    private static final int CARROT_STATE = 1;
    private static final int BAD_CARROT_STATE = 2;

    // resource counters
    private int carrotCount = 0;
    private int badCarrotCount = 0;

    // game state
    private int gameState = 0; // 0: Intro, 1: Playing

    private BufferedImage startImg;
    private BufferedImage titleImg;

    // pollution clouds
    private ArrayList<PollutionCloud> cloudList = new ArrayList<>();
    private int cloudGenInterval = 1600;
    private long lastCloudGenTime = System.currentTimeMillis();
    private javax.swing.Timer cloudTimer;

    // celebration for first harvest
    private boolean carrotCelebrated = false;
    private boolean badCarrotCelebrated = false;
    private long celebrateStartTime = 0;
    private int celebrateType = 0; // 1: carrot, 2: badcarrot

    //Rabbit
    private Rabbit rabbit;
    private BufferedImage rabbitImg;          // 平时图 / normal
    private BufferedImage carrotRabbitImg;    // 喂食图 / feeding
    private javax.swing.Timer rabbitTimer;    // 扣血计时器 / HP decrease timer

   
    //private Robot robot;                      // 场上唯一机器人实例 / single robot instance
    private BufferedImage robotImg;           // 普通图 / normal
    private BufferedImage robotEatingImg;     // 吃东西图（未来触发）/ eating (for later)
    private javax.swing.Timer robotSpawnTimer;// 10 秒后生成 / spawn after 10s
    private boolean robotSpawned = false;     // 是否已生成 / spawned flag

    // Game Over
    private BufferedImage gameOverImg;
    private boolean isGameOver = false;

    //private boolean robotHitLock = false;
    
    private ArrayList<Robot> robots = new ArrayList<>();
    
 // FIRE 
 
    private int fireBtnX = 24, fireBtnY = 620, fireBtnW = 110, fireBtnH = 36;


    private ArrayList<Bullet> bullets = new ArrayList<>();
    
    
    //Music
    private Minim minim;
    private AudioPlayer themeMusic;
    
    private AudioSample eatSound;
    private AudioSample shootSound; 

    
    
    public FarmPanel() {
    	//Music
    	minim = new Minim(new MinimHelper());
    	themeMusic = minim.loadFile("theme.mp3", 2048); 
    	themeMusic.loop(); 
    	eatSound = minim.loadSample("eat.mp3", 512);
    	shootSound = minim.loadSample("shoot.mp3", 512);
    	
    	if (shootSound != null) shootSound.setGain(6); 
        // / load images
        bgImg = ImageLoader.loadImage("assets/gamebackground.png");
        seedImg = ImageLoader.loadImage("assets/gameseed.png");
        carrotImg = ImageLoader.loadImage("assets/gamecarrot.png");
        badCarrotImg = ImageLoader.loadImage("assets/badcarrot.png");
        startImg = ImageLoader.loadImage("assets/start.png");
        titleImg = ImageLoader.loadImage("assets/title.png");
        rabbitImg = ImageLoader.loadImage("assets/rabbit.png");
        carrotRabbitImg = ImageLoader.loadImage("assets/carrotrabbit.png"); // 喂食时显示 / feeding image
        gameOverImg = ImageLoader.loadImage("assets/gameover.png");

        // robot images
        robotImg = ImageLoader.loadImage("assets/robot.png");
        robotEatingImg = ImageLoader.loadImage("assets/roboteating.png");

        setPreferredSize(new Dimension(896, 768));
        rabbit = new Rabbit(rabbitImg,carrotRabbitImg, 896, 768);
       
        // HP timer only runs when playing
        rabbitTimer = new javax.swing.Timer(1000, e -> {
            if (gameState != 1 || isGameOver) return;
            rabbit.decreaseHealth(2); // 每秒 -2 HP / -2 HP per second
            if (rabbit.getHealth() <= 0 && !isGameOver) {
                isGameOver = true;
                if (runStartMs > 0) {
                    surviveSeconds = Math.max(0, (System.currentTimeMillis() - runStartMs) / 1000);
                }
            }
            repaint();
        });

        //  mouse listeners
        addMouseListener(this);
        addMouseMotionListener(this);

        //  cloud animation
        cloudList.add(new PollutionCloud(896));
        cloudTimer = new javax.swing.Timer(40, e -> {
            if (gameState == 1) {
                // update clouds
                for (int i = 0; i < cloudList.size(); i++) {
                    PollutionCloud pc = cloudList.get(i);
                    pc.update(getWidth());
                    if (pc.isOut(getWidth())) {
                        cloudList.remove(i);
                        i--;
                    }
                }
                if (System.currentTimeMillis() - lastCloudGenTime > cloudGenInterval) {
                    cloudList.add(new PollutionCloud(getWidth()));
                    lastCloudGenTime = System.currentTimeMillis();
                }

                // update all robots
                for (Robot r : robots) {
                    r.update(getWidth(), getHeight(),  rabbit.getY());
                }

                //  robots eat carrots
                for (Robot r : robots) {
                    Rectangle rb = r.getBounds();
                    boolean ate = false;
                    for (int rr = 0; rr < tileRows && !ate; rr++) {
                        for (int cc = 0; cc < tileCols && !ate; cc++) {
                            if (cropState[rr][cc] == CARROT_STATE) {
                                int tx = fieldStartX + cc * tileWidth;
                                int ty = fieldStartY + rr * tileHeight;
                                Rectangle tileRect = new Rectangle(tx, ty, tileWidth, tileHeight);
                                if (rb.intersects(tileRect)) {
                                    cropState[rr][cc] = SEED_STATE;//eaten
                                    r.startEating();
                                    if (eatSound != null) eatSound.trigger(); 
                                    ate = true;
                                }
                            }
                        }
                    }
                }

                // hit once per overlap
                Rectangle rab = rabbit.getBounds();
                for (Robot r : robots) {
                    Rectangle rb = r.getBounds();
                    boolean overlapping = rb.intersects(rab);
                    if (overlapping && !r.hitLock) {
                        rabbit.decreaseHealth(10);
                        rabbit.startRotation();// visual feedback
                        r.hitLock = true;
                    } else if (!overlapping) {
                        r.hitLock = false;
                    }
                }
             // bullets update & collisions
                for (int i = 0; i < bullets.size(); i++) {
                    Bullet b = bullets.get(i);
                    b.update();

                    //off-screen cleanup
                    if (b.isOut(getWidth(), getHeight())) {
                      
                        
                        bullets.remove(i);
                        i--;
                        continue;
                    }

               
                    Rectangle bb = b.getBounds();
                    boolean hit = false;
                    for (int j = 0; j < robots.size() && !hit; j++) {
                        Robot r = robots.get(j);
                        if (bb.intersects(r.getBounds())) {
                            
                            robots.remove(j);
                          
                            bullets.remove(i);
                            i--;
                            hit = true;
                        }
                    }
                }

                repaint();
            }
        });
        cloudTimer.start();

        robotSpawnTimer = new javax.swing.Timer(10000, e -> {
            if (gameState == 1 && !isGameOver) {
            	 for (int k = 0; k < 2; k++) { 
                     robots.add(new Robot(robotImg, robotEatingImg, getWidth(), getHeight(), rabbit.getY()));
                     
                     robotTipStartMs = System.currentTimeMillis(); 

                 }

            }
        });
        robotSpawnTimer.setRepeats(true); //fire every 10s
    }

    public void stopMusic() {
        if (themeMusic != null) themeMusic.close();
        if (minim != null) minim.stop();
        if (eatSound != null) eatSound.close();
        if (shootSound != null) shootSound.close(); 
    }
    
    // recursive fractal decor
    private void drawFractalDecor(Graphics2D g2, int x, int y, double r, int depth) {
        if (depth <= 0) return;
        g2.setColor(new Color(200, 160, 255, 65 + depth * 30));
        g2.setStroke(new BasicStroke((float) (depth * 3.5)));
        g2.drawOval((int)(x - r), (int)(y - r), (int)(2*r), (int)(2*r));
        for (int i = 0; i < 6; i++) {
            double angle = Math.PI * 2 * i / 6;
            int nx = (int)(x + Math.cos(angle) * r);
            int ny = (int)(y + Math.sin(angle) * r);
            drawFractalDecor(g2, nx, ny, r * 0.45, depth - 1);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Intro screen
        if (gameState == 0) {
            if (bgImg != null) g.drawImage(bgImg, 0, 0, getWidth(), getHeight(), null);

            if (titleImg != null) {
                int tw = 580, th = 300;
                int tx = (getWidth() - tw) / 2;
                int ty = getHeight() / 6 - 100;
                g.drawImage(titleImg, tx, ty, tw, th, null);

                int textBaseY = ty + th + 30;
                int textBaseX = (getWidth() - tw) / 2 + 10;
                g.setColor(new Color(20,20,20,180));
                g.fillRoundRect(textBaseX-10, textBaseY, 600, 210, 24, 24);
                g.setColor(Color.WHITE);
                g.setFont(new Font("Arial", Font.BOLD, 22));
                g.drawString("Survive with Your Cyber Rabbit!", textBaseX, textBaseY + 35);
                g.setFont(new Font("Arial", Font.PLAIN, 18));
                g.drawString("In a post-apocalyptic world, you must raise and protect a cyber rabbit.", textBaseX, textBaseY + 70);
                g.drawString("Grow carrots to feed your rabbit and keep it healthy.", textBaseX, textBaseY + 95);
                g.drawString("If you don't feed your rabbit, it will lose health.", textBaseX, textBaseY + 120);
                g.drawString("Robots will appear to attack your rabbit, causing health loss.", textBaseX, textBaseY + 145);
                g.drawString("Collect bad carrots for bullets to fight robots. (Bad carrots are rare!)", textBaseX, textBaseY + 170);
                g.drawString("Your goal: Keep your cyber rabbit alive as long as possible!", textBaseX, textBaseY + 195);
            }

            if (startImg != null) {
                int sw = 250, sh = 100;
                int sx = (getWidth() - sw) / 2;
                int sy = (getHeight() * 2 / 3) + 100;
                g.drawImage(startImg, sx, sy, sw, sh, null);
            }
            return;
        }

        //  background
        if (bgImg != null) g.drawImage(bgImg, 0, 0, getWidth(), getHeight(), null);
        else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        // clouds
        for (PollutionCloud pc : cloudList) pc.draw(g2);

        // rabbit + FEED button
        if (gameState == 1) {
        	rabbit.draw(g2);

            rabbit.drawFeedButton(g2, carrotCount);
         
            if (robotTipStartMs > 0 && (System.currentTimeMillis() - robotTipStartMs) < ROBOT_TIP_DURATION_MS) {
                String tip = "Robots are coming!";
           
                
                Font old = g2.getFont();
                g2.setFont(new Font("Arial", Font.BOLD, 26)); 

                int sw = g2.getFontMetrics().stringWidth(tip);
                int sh = g2.getFontMetrics().getAscent();

                int rx = rabbit.getX();
                int ry = rabbit.getY();
                int rw = rabbit.getW();
                int bx = rx + (rw - sw) / 2;
                int by = ry - 16; 

      
                int padX = 12, padY = 8;
                g2.setColor(new Color(0, 0, 0, 140));
                g2.fillRoundRect(bx - padX, by - sh, sw + padX*2, sh + padY, 12, 12);

                g2.setColor(Color.WHITE);
                g2.drawString(tip, bx, by);

                g2.setFont(old);
            }

            
          
            if (tipStartMs > 0 && (System.currentTimeMillis() - tipStartMs) < TIP_DURATION_MS) {
                String tip = "Click the seed and plant it in the field.";
              
                Font old = g2.getFont();
                g2.setFont(new Font("Arial", Font.BOLD, 26)); // 可调为 28/32

                int sw = g2.getFontMetrics().stringWidth(tip);
                int sh = g2.getFontMetrics().getAscent();

                int rx = rabbit.getX();
                int ry = rabbit.getY();
                int rw = rabbit.getW();
                int bx = rx + (rw - sw) / 2;
                int by = ry - 16; 

                int padX = 12, padY = 8;
                g2.setColor(new Color(0, 0, 0, 140));
                g2.fillRoundRect(bx - padX, by - sh, sw + padX*2, sh + padY, 12, 12);

                g2.setColor(Color.WHITE);
                g2.drawString(tip, bx, by);

                g2.setFont(old);
            }
        }
  
        //FIRE button
        fireBtnY = rabbit.getY() + rabbit.getH() - 40;
        fireBtnX = rabbit.getX() - fireBtnW - 14;


        {
            boolean canFire = (badCarrotCount > 0 && !robots.isEmpty() && gameState == 1 && !isGameOver);
            Graphics2D g2d = g2;

            if (canFire) g2d.setColor(new Color(200, 80, 60));  // 可用时红色
            else g2d.setColor(new Color(120, 120, 120));        // 不可用置灰
            g2d.fillRoundRect(fireBtnX, fireBtnY, fireBtnW, fireBtnH, 10, 10);

            g2d.setColor(Color.BLACK);
            g2d.drawRoundRect(fireBtnX, fireBtnY, fireBtnW, fireBtnH, 10, 10);

            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.setColor(Color.WHITE);
            String t = "FIRE";
            int tsw = g2d.getFontMetrics().stringWidth(t);
            int tsh = g2d.getFontMetrics().getAscent();
            g2d.drawString(t, fireBtnX + (fireBtnW - tsw) / 2, fireBtnY + (fireBtnH + tsh) / 2 - 3);
        }



        //  field tiles & crops
        Color fillBrown = new Color(210, 180, 140);
        Color borderBrown = new Color(139, 69, 19);
        for (int row = 0; row < tileRows; row++) {
            for (int col = 0; col < tileCols; col++) {
                int x = fieldStartX + col * tileWidth;
                int y = fieldStartY + row * tileHeight;
                g.setColor(fillBrown);
                g.fillRect(x, y, tileWidth, tileHeight);
                g.setColor(borderBrown);
                g.drawRect(x, y, tileWidth, tileHeight);

                if (tileHasSeed[row][col] && seedImg != null) {
                    int seedW = seedIconW, seedH = seedIconH;
                    int cx = x + (tileWidth - seedW) / 2;
                    int cy = y + (tileHeight - seedH) / 2;
                    g.drawImage(seedImg, cx, cy, seedW, seedH, null);
                } else if (cropState[row][col] == CARROT_STATE && carrotImg != null) {
                    int cx = x + (tileWidth - seedIconW) / 2;
                    int cy = y + (tileHeight - seedIconH) / 2;
                    g.drawImage(carrotImg, cx, cy, seedIconW, seedIconH, null);
                } else if (cropState[row][col] == BAD_CARROT_STATE && badCarrotImg != null) {
                    int cx = x + (tileWidth - seedIconW) / 2;
                    int cy = y + (tileHeight - seedIconH) / 2;
                    g.drawImage(badCarrotImg, cx, cy, seedIconW, seedIconH, null);
                }
            }
        }
     //  draw all robots
        for (Robot r : robots) {
            r.draw(g2);
        }
     
        for (Bullet b : bullets) {
            b.draw(g2);
        }
        // seed icon & label
        if (seedImg != null) {
            int iconX = seedIconX - 40;
            int iconY = seedIconY + 120;
            g.drawImage(seedImg, iconX, iconY, 40, 40, null);

            // highlight when holding seed
            if (holdingSeed) {
                g.setColor(new Color(60, 150, 90));
                g.drawRoundRect(iconX - 1, iconY - 1, 42, 42, 8, 8);
            }
        }
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Seed", seedIconX - 40, seedIconY + seedIconH + 120);

        // seed following mouse when holding
        if (holdingSeed && seedImg != null) {
            g.drawImage(seedImg, mouseX - seedIconW / 2, mouseY - seedIconH / 2, seedIconW, seedIconH, null);
        }

        //counters
        if (carrotImg != null) {
            g.drawImage(carrotImg, seedIconX - 40, seedIconY - seedIconH - 20 + 120, 40, 40, null);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("carrot X" + carrotCount, seedIconX - 40, seedIconY + 120 + seedIconH - 80);
        }
        if (badCarrotImg != null) {
            g.drawImage(badCarrotImg, seedIconX - 40, seedIconY - seedIconH - 100 + 120, 40, 40, null);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("badcarrot X" + badCarrotCount, seedIconX - 60, seedIconY + seedIconH - 160 + 120);
        }

        // celebration 
        if ((carrotCelebrated || badCarrotCelebrated) && System.currentTimeMillis() - celebrateStartTime < 1500) {
            drawFractalDecor(g2, getWidth() / 2, getHeight() / 2, 120, 4);
            BufferedImage centerImg = (celebrateType == 1 ? carrotImg : badCarrotImg);
            if (centerImg != null) {
                int imgW = 140, imgH = 140;
                g2.drawImage(centerImg, getWidth() / 2 - imgW / 2, getHeight() / 2 - imgH / 2, imgW, imgH, null);
            }
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 36));
            String text = (celebrateType == 1 ? "carrot!" : "badcarrot!");
            int strW = g2.getFontMetrics().stringWidth(text);
            g2.drawString(text, getWidth() / 2 - strW / 2, getHeight() / 2 + 100);
            repaint();
        }

        // game over overlay
        if (isGameOver) {
            g2.setColor(new Color(0, 0, 0, 150));
            g2.fillRect(0, 0, getWidth(), getHeight());

            if (gameOverImg != null) {
                int imgW = 380, imgH = 220;
                int x = (getWidth() - imgW) / 2;
                int y = (getHeight() - imgH) / 2 - 30;
                g2.drawImage(gameOverImg, x, y, imgW, imgH, null);
            }
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.PLAIN, 22));
            String msg = "Click anywhere to restart the game.";
            int msgW = g2.getFontMetrics().stringWidth(msg);
            g2.drawString(msg, getWidth() / 2 - msgW / 2, getHeight() / 2 + 120);
            
            String survivalNow = "Survival time: " + surviveSeconds + " s";
            int swNow = g2.getFontMetrics().stringWidth(survivalNow);
            g2.drawString(survivalNow, getWidth() / 2 - swNow / 2, getHeight() / 2 + 150);
            return;
        }
    }

    // ===== Mouse =====
    @Override
    public void mousePressed(MouseEvent e) {
        //  restart on click
        if (isGameOver) {
            rabbitTimer.stop();
            resetGame();
            isGameOver = false;
            gameState = 0; // back to intro
            repaint();
            return;
        }

        if (gameState == 0) {
            // Start button
            int sw = 250, sh = 100;
            int sx = (getWidth() - sw) / 2;
            int sy = (getHeight() * 2 / 3) + 100;
            if (e.getX() >= sx && e.getX() <= sx + sw && e.getY() >= sy && e.getY() <= sy + sh) {
                gameState = 1;
                runStartMs = System.currentTimeMillis(); 
                surviveSeconds = 0L;
                isGameOver = false;
                runStartMs = System.currentTimeMillis(); 
                surviveSeconds = 0L;                    
                tipStartMs = System.currentTimeMillis(); 
                
                rabbitTimer.start();   // start HP timer
                //  (re)start 10s robot spawn timer
                if (robotSpawnTimer != null) {
                    
                    robots.clear();    
                    robotSpawnTimer.restart();
                }
                repaint();
            }
            return;
        }

        int mx = e.getX(), my = e.getY();

      
        // Toggle holding seed by clicking the seed icon
        if (mx >= seedIconX - 40 && mx <= seedIconX
                && my >= seedIconY + 120 && my <= seedIconY + 160) {
            holdingSeed = !holdingSeed;
            repaint();
            return;
        }
    
        if (mx >= fireBtnX && mx <= fireBtnX + fireBtnW && my >= fireBtnY && my <= fireBtnY + fireBtnH) {
            if (!holdingSeed && gameState == 1 && !isGameOver && badCarrotCount > 0 && !robots.isEmpty()) {
        
                Robot target = null;
                double bestDist = Double.MAX_VALUE;
                int rx = rabbit.getX() + rabbit.getW() / 2;
                int ry = rabbit.getY() + rabbit.getH() / 2;
                for (Robot r : robots) {
                    Rectangle rb = r.getBounds();
                    int cx = rb.x + rb.width / 2;
                    int cy = rb.y + rb.height / 2;
                    double d = Math.hypot(cx - rx, cy - ry);
                    if (d < bestDist) { bestDist = d; target = r; }
                }
                if (target != null) {
                    Rectangle tb = target.getBounds();
                    float tx = tb.x + tb.width / 2.0f;
                    float ty = tb.y + tb.height / 2.0f;

                   
                    bullets.add(new Bullet(rx, ry, tx, ty));
                    
                    
                 
                    if (shootSound != null) {
              
                        shootSound.trigger();
                    }
                    
                 //  consume ammo on fire
                    badCarrotCount--;
                    
                    if (badCarrotCount < 0) badCarrotCount = 0; 
                }
                repaint();
            }
            return;
        }

   
        // FEED button: disabled while holding a seed
        if (gameState == 1 && !isGameOver && !holdingSeed && rabbit.isFeedButtonHit(mx, my)) {
        	if (carrotCount > 0 && rabbit.getHealth() < 100) {
                carrotCount--;
                rabbit.increaseHealth(3);
         
                rabbit.startFeeding();
                if (eatSound != null) eatSound.trigger();  
                repaint();
            }
            return;
        }

        // field click: harvest or plant
        for (int row = 0; row < tileRows; row++) {
            for (int col = 0; col < tileCols; col++) {
                int x = fieldStartX + col * tileWidth;
                int y = fieldStartY + row * tileHeight;

                if (mx >= x && mx <= x + tileWidth && my >= y && my <= y + tileHeight) {

                
                    // Holding seed: only plant on empty tile; no harvest
                    if (holdingSeed) {
                        if (!tileHasSeed[row][col] && cropState[row][col] == SEED_STATE) {
                            tileHasSeed[row][col] = true;
                            cropState[row][col] = SEED_STATE;

                            final int r = row, c = col;
                            if (growTimers[r][c] != null) growTimers[r][c].stop();

                      
                            // Mature after 10s (change the value to adjust)
                            growTimers[r][c] = new Timer(5000, ev -> {
                                int result = (new java.util.Random().nextInt(4) == 0) ? BAD_CARROT_STATE : CARROT_STATE;
                                cropState[r][c] = result;
                                tileHasSeed[r][c] = false;
                                growTimers[r][c].stop();
                                repaint();
                            });
                            growTimers[r][c].setRepeats(false);
                            growTimers[r][c].start();

                            repaint();
                        }
                        return; // no harvest when holding seed
                    }

                    //  Not holding seed: harvest allowed
                    if (cropState[row][col] == CARROT_STATE) {
                        carrotCount++;
                        cropState[row][col] = SEED_STATE;
                        if (!carrotCelebrated) {
                            carrotCelebrated = true;
                            celebrateType = 1;
                            celebrateStartTime = System.currentTimeMillis();
                        }
                        repaint();
                        return;
                    }
                    if (cropState[row][col] == BAD_CARROT_STATE) {
                        badCarrotCount++;
                        cropState[row][col] = SEED_STATE;
                        if (!badCarrotCelebrated) {
                            badCarrotCelebrated = true;
                            celebrateType = 2;
                            celebrateStartTime = System.currentTimeMillis();
                        }
                        repaint();
                        return;
                    }

                    return; //  click empty tile does nothing
                }
            }
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        mouseX = e.getX();
        mouseY = e.getY();
        if (holdingSeed) repaint();
    }

    @Override public void mouseDragged(MouseEvent e) { mouseMoved(e); }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
    @Override public void mouseClicked(MouseEvent e) {}

    //  Reset all states
    private void resetGame() {
        carrotCount = 0;
        badCarrotCount = 0;
        holdingSeed = false;

        for (int i = 0; i < tileRows; i++) {
            for (int j = 0; j < tileCols; j++) {
                tileHasSeed[i][j] = false;
                cropState[i][j] = SEED_STATE;
                if (growTimers[i][j] != null) growTimers[i][j].stop();
            }
        }

        cloudList.clear();
        cloudList.add(new PollutionCloud(getWidth()));

        carrotCelebrated = false;
        badCarrotCelebrated = false;

        rabbit.enableHealth(100);  // reset HP
        rabbitTimer.stop();   // stop HP timer

        robots.clear();                           // clear all robots
        if (robotSpawnTimer != null) robotSpawnTimer.stop(); //  stop timer

    }
}