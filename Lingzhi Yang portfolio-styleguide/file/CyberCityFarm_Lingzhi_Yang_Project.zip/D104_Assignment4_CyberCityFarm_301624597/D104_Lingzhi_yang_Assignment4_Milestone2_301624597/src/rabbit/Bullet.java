package rabbit;

/**
  Bullet — Projectile fired by the rabbit:
  Stores position and velocity using PVector.
  Moves toward the target with a fixed speed.
 */


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import processing.core.PVector;

public class Bullet {
    public PVector pos;
    public PVector vel;
    public float speed = 8;
    public int size = 12;

    public Bullet(float startX, float startY, float targetX, float targetY) {
        pos = new PVector(startX, startY);
        PVector dir = new PVector(targetX - startX, targetY - startY);
        if (dir.mag() == 0) dir = new PVector(1, 0);
        dir.normalize();
        vel = dir.mult(speed);
    }

    public void update() { pos.add(vel); }

    public void draw(Graphics2D g2) {
        g2.setColor(new Color(255, 230, 80));
        g2.fillOval((int)(pos.x - size/2), (int)(pos.y - size/2), size, size);
        g2.setColor(Color.BLACK);
        g2.drawOval((int)(pos.x - size/2), (int)(pos.y - size/2), size, size);
    }

    public boolean isOut(int w, int h) {
        return pos.x < -size || pos.x > w + size || pos.y < -size || pos.y > h + size;
    }

    public Rectangle getBounds() {
        return new Rectangle((int)(pos.x - size/2), (int)(pos.y - size/2), size, size);
    }
}
