package creature;

import java.awt.Graphics2D;

import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

/**
 * Creature base class:
 *  - Defines position, size, velocity for all game creatures.
 *  - Provides basic movement, collision bounds, optional health system.
 *  - Offers helper for image drawing with optional rotation.
 *  - Subclasses must implement their own draw() method.
 */
public abstract class Creature {
    //core state
    protected int x, y, w, h;//position & size
    protected int vx, vy;// velocity

    
    protected int health = -1; 
    //  common API

   //Basic movement
    public void update(int panelW, int panelH) {
        x += vx;
        y += vy;
    }

   //Subclasses must implement how to draw themselves
    public abstract void draw(Graphics2D g2);

  //Axis-aligned bounding box for simple collision checks
    public Rectangle getBounds() {
        return new Rectangle(x, y, w, h);
    }

    // health helpers (optional)
    public void enableHealth(int initial) {
        health = Math.max(0, Math.min(100, initial));
    }

    public boolean hasHealth() {
        return health >= 0;
    }

    public int getHealth() {
        return health;
    }

    public void decreaseHealth(int amount) {
        if (!hasHealth()) return;
        health -= amount;
        if (health < 0) health = 0;
    }

    public void increaseHealth(int amount) {
        if (!hasHealth()) return;
        health += amount;
        if (health > 100) health = 100;
    }

    // image draw helper with optional rotation 
    protected void drawImage(Graphics2D g2, BufferedImage img, int extraDy, int rotateDeg) {
        if (img == null) return;
        if (rotateDeg != 0) {
            AffineTransform old = g2.getTransform();
            double cx = x + w / 2.0;
            double cy = y + h / 2.0;
            g2.rotate(Math.toRadians(rotateDeg), cx, cy);
            g2.drawImage(img, x, y + extraDy, w, h, null);
            g2.setTransform(old);
        } else {
            g2.drawImage(img, x, y + extraDy, w, h, null);
        }
    }

    // convenience accessors
    public int getX() { return x; }
    public int getY() { return y; }
    public int getW() { return w; }
    public int getH() { return h; }
    public void setPos(int x, int y) { this.x = x; this.y = y; }
    public void setSize(int w, int h) { this.w = w; this.h = h; }
    public void setVel(int vx, int vy) { this.vx = vx; this.vy = vy; }
}
