package rabbit;

import creature.Creature;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.geom.AffineTransform;

/**
 * [EN] Rabbit — Main controllable creature in the game:
 *  - Extends Creature, includes normal and feeding images.
 *  - Can rotate or "bob" when feeding, with timed animation.
 *  - Displays health bar with numerical HP value.
 *  - Has a clickable FEED button.
 */
public class Rabbit extends Creature {
    public BufferedImage img;       //  normal
    private BufferedImage feedImg;  // feeding

    // Feed 
    public int feedBtnX, feedBtnY, feedBtnW = 90, feedBtnH = 36;

    
    private boolean rotating = false;
    private double angleDeg = 0;
    private double rotateSpeed = 20;

  
    private boolean feeding = false;
    private long feedStartTime;
    private int feedDuration = 600; 
    private int feedBobAmp = 6;

    public Rabbit(BufferedImage normalImg, BufferedImage feedImg, int panelWidth, int panelHeight) {
        this.img = normalImg;
        this.feedImg = feedImg;

        this.w = 110;
        this.h = 150;
        this.x = panelWidth / 2 - w / 2;
        this.y = panelHeight / 2 - h / 2;

        //enable health
        enableHealth(100);
    }

    public void setFeedImage(BufferedImage img) {
        this.feedImg = img;
    }

    // Starting Feeding
    public void startFeeding() {
        feeding = true;
        feedStartTime = System.currentTimeMillis();
    }


    public void startRotation() {
        rotating = true;
        angleDeg = 0;
    }

    @Override
    public void draw(Graphics2D g2) {
        
        BufferedImage currentImg = img;
        int dy = 0;

        if (feeding) {
            if (feedImg != null) currentImg = feedImg;
            long t = System.currentTimeMillis() - feedStartTime;
            dy = (int) Math.round(Math.sin(t / 60.0) * feedBobAmp);
            if (t > feedDuration) {
                feeding = false;
            }
        }


        int rot = 0;
        if (rotating) {
            rot = (int) Math.round(angleDeg);
            angleDeg += rotateSpeed;
            if (angleDeg >= 360) {
                angleDeg = 0;
                rotating = false;
            }
        }
        drawImage(g2, currentImg, dy, rot);

   
        if (hasHealth()) {
            int barW = 120, barH = 16;
            int bx = x + w / 2 - barW / 2;
            int by = y - 28;
            int healthFill = (int) (barW * (getHealth() / 100.0));

            g2.setColor(Color.LIGHT_GRAY);
            g2.fillRect(bx, by, barW, barH);
            g2.setColor(new Color(220, 40, 60));
            g2.fillRect(bx, by, healthFill, barH);
            g2.setColor(Color.BLACK);
            g2.drawRect(bx, by, barW, barH);

            g2.setFont(new Font("Arial", Font.BOLD, 15));
            g2.setColor(Color.WHITE);
            String hpStr = getHealth() + " / 100";
            int sw = g2.getFontMetrics().stringWidth(hpStr);
            g2.drawString(hpStr, bx + (barW - sw) / 2, by + barH - 2);
        }
    }

    //  Feed 
    public void drawFeedButton(Graphics2D g2, int carrotCount) {
        feedBtnX = x + w + 10;
        feedBtnY = y + h - 40;

        if (carrotCount > 0) g2.setColor(new Color(60, 150, 90));
        else g2.setColor(new Color(120, 120, 120));
        g2.fillRoundRect(feedBtnX, feedBtnY, feedBtnW, feedBtnH, 10, 10);

        g2.setColor(Color.BLACK);
        g2.drawRoundRect(feedBtnX, feedBtnY, feedBtnW, feedBtnH, 10, 10);

        g2.setFont(new Font("Arial", Font.BOLD, 16));
        g2.setColor(Color.WHITE);
        String btnText = "FEED";
        int tsw = g2.getFontMetrics().stringWidth(btnText);
        int tsh = g2.getFontMetrics().getAscent();
        g2.drawString(btnText, feedBtnX + (feedBtnW - tsw) / 2, feedBtnY + (feedBtnH + tsh) / 2 - 3);
    }

    // Feed button
    public boolean isFeedButtonHit(int mx, int my) {
        int bx = x + w + 10;
        int by = y + h - 40;
        return mx >= bx && mx <= bx + feedBtnW && my >= by && my <= by + feedBtnH;
    }

    
    public void decreaseHealth(int amount) { super.decreaseHealth(amount); }
    public void increaseHealth(int amount) { super.increaseHealth(amount); }

    
    @Override
    public Rectangle getBounds() {
        return super.getBounds();
    }
}
