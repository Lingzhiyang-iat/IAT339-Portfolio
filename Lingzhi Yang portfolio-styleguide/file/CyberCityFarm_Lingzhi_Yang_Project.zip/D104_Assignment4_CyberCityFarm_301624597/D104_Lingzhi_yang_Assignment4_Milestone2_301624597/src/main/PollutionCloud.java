package main;


/**
 PollutionCloud — Visual effect for drifting grey clouds:
 */

//Perlin noise
import processing.core.PApplet;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class PollutionCloud {
    private float x;
    private float y;
    private float speed;
    private float width;
    private float height;
    private float noiseSeed;
    private PApplet pa = new PApplet();
    private Color color;
    private Random random = new Random();

    public PollutionCloud(int panelWidth) {
        width = 140 + random.nextInt(60);     
        height = 45 + random.nextInt(20);      
        x = -width;
        y = 30 + random.nextInt(25);          
        speed = 2.0f + random.nextFloat() * 0.7f; 
        noiseSeed = random.nextFloat() *20;
        int grey = 140 + random.nextInt(60);
        color = new Color(grey, grey, grey, 80 + random.nextInt(40)); 
    }

    public void draw(Graphics2D g2) {
      
        float centerX = x + width / 2;
        float centerY = y + height / 2;

        for (int i = 0; i < 8; i++) {
            float offsetAngle = (float) (Math.PI * 2 * i / 8 + noiseSeed);
            float nx = (float) (centerX + Math.cos(offsetAngle) * width * 0.18 + random.nextFloat() * 10);
            float ny = (float) (centerY + Math.sin(offsetAngle) * height * 0.21 + random.nextFloat() * 8);
            float ew = width * (0.45f + random.nextFloat() * 0.2f);
            float eh = height * (0.45f + random.nextFloat() * 0.19f);
            g2.setColor(color);
            g2.fill(new Ellipse2D.Float(nx - ew / 2, ny - eh / 2, ew, eh));
        }
        
        g2.fill(new Ellipse2D.Float(centerX - width * 0.32f, centerY - height * 0.34f, width * 0.67f, height * 0.68f));
    }

    public void update(int panelWidth) {
        x += speed;
    }

    public boolean isOut(int panelWidth) {
        return x > panelWidth;
    }
}
